package hr_data
import java.io.IOException
import org.apache.spark.sql.functions
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SparkSession;

object stack_exchange {

  def main(args: Array[String]): Unit = {
    val props = ConfigFactory.load()
    val envProps = props.getConfig(args(0))

    val spark = SparkSession
      .builder
      .master(envProps.getString("execution.mode"))
      .appName("Stack Exchange Data")
      .getOrCreate

    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.shuffle.partitions", "2")

    try {
      val inputBaseDir = envProps.getString("input.stack_exchange.base.dir")
      val outputBaseDir = envProps.getString("output.base.dir")

//      val customSchema = StructType(Array(
//        StructField("_AcceptedAnswerId", LongType, nullable = true),
//        StructField("_AnswerCount", LongType, nullable = true),
//        StructField("_Body", StringType, nullable = true),
//        StructField("_ClosedDate", StringType, nullable = true),
//        StructField("_CommentCount", LongType ,nullable = true),
//        StructField("_CommunityOwnedDate", DoubleType, nullable = true),
//        StructField("CreationDate", StringType, nullable = true),
//        StructField("_FavoriteCount", LongType ,nullable = true),
//        StructField("Id", LongType ,nullable = true),
//        StructField("_LastActivityDate", StringType, nullable = true),
//        StructField("_LastEditDate", StringType, nullable = true),
//        StructField("_LastEditorDisplayName", StringType, nullable = true),
//        StructField("_LastEditorUserId", LongType ,nullable = true),
//        StructField("_OwnerDisplayName", StringType, nullable = true),
//        StructField("_OwnerUserId", LongType ,nullable = true),
//        StructField("_ParentId", LongType ,nullable = true),
//        StructField("_PostTypeId", LongType ,nullable = true),
//        StructField("_Score", LongType ,nullable = true),
//        StructField("_Tags", StringType, nullable = true),
//        StructField("_Title", StringType, nullable = true),
//        StructField("_VALUE", StringType, nullable = true),
//        StructField("_ViewCount", LongType ,nullable = true)))

      val stExDF = spark.sqlContext.read
        .format("com.databricks.spark.xml")
        .option("rowTag","posts")
        .load(inputBaseDir)

//      stExDF.printSchema()

      var exploded = stExDF.select(functions.explode(stExDF("row")).as("r"))
        .select("r._Id",
          "r._AcceptedAnswerId",
          "r._AnswerCount",
          "r._Body",
          "r._ClosedDate",
          "r._CommentCount",
          "r._CommunityOwnedDate",
          "r._CreationDate",
          "r._FavoriteCount",
          "r._LastActivityDate",
          "r._LastEditDate",
          "r._LastEditorDisplayName",
          "r._OwnerDisplayName",
          "r._OwnerUserId",
          "r._ParentId",
          "r._PostTypeId",
          "r._Score",
          "r._Tags",
          "r._Title",
          "r._VALUE",
          "r._ViewCount")

      exploded.show(2,true)

      exploded.createOrReplaceTempView("stExchange")

      /*1*/
      spark.sql("select count(_Id) as TotalQuestions from stExchange where _Title not like ''").show(10)
      spark.sql("select _Id as Question_Ids from stExchange").show(10)

      /*3*/
      spark.sql("select _Title, count(_Title) as NoOfPosts from stExchange where _Title like '%hadoop%' or _Title like '%data%' or _Title like '%science%' or _Title like '%spark%' or _Title like '%nosql%' order by NoOfPosts desc").show(10,false)

      /*4*/
      spark.sql("select _Title, _ViewCount,_Score from stExchange order by _ViewCount desc, _Score desc limit 10").show(10,false)

      /*5*/
      spark.sql("select count(_Id) as QuesWithNoAns from stExchange where _AnswerCount = 0").show(5000)

      /*6*/
      spark.sql("select count(_Id) as QuesWithMoreAns  from stExchange where _AnswerCount > 2").show(5000)

      /*9*/
      spark.sql("select _Tags, count(_Score) as MostScore from stExchange where _Tags like '%hadoop%' or _Tags like '%spark%' group by _Tags order by MostScore desc limit 10").show(10,false)

      /*10*/
      spark.sql("select _Tags, count(_Tags) as Count from stExchange group by _Tags").show(5000,false)

      /*11*/
      spark.sql("select count(_id) as QuesWithSpecificTags from stExchange where (_Tags like '%nosql%' or  _Tags like '%big data%') and _CreationDate like '%2015%'").show(5000)

//      exploded = exploded.select(exploded.col("_Id").as("Id"), exploded.col("_ViewCount").as("ViewCount"))
//      exploded.show(100,false)
    }
    catch {
      case e: IOException => e.printStackTrace()
    }

  }
}
