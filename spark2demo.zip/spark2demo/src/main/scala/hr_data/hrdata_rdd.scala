package hr_data

import java.io.IOException

import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SparkSession

import scala.io.Source

object hrdata_rdd {
  def main(args: Array[String]): Unit = {
    //val props = ConfigFactory.load()
    //val envProps = props.getConfig(args(0))

    val props = ConfigFactory.load()
    val envProps = props.getConfig(args(0))

    val spark = SparkSession
      .builder
      .master(envProps.getString("execution.mode"))
      .appName("HR Sample Data RDD")
      .getOrCreate

    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.shuffle.partitions", "2")

    try {
      val inputBaseDir = envProps.getString("input.base.dir")
      val outputBaseDir = envProps.getString("output.base.dir")

      val hrRaw = Source.fromFile(inputBaseDir).getLines().toList
      val hrRddWithHeader = spark.sparkContext.parallelize(hrRaw)
      val header = hrRddWithHeader.first()
      val hrRdd = hrRddWithHeader.filter(f => f != header).map(f => {
        (f.split(",")(0).toDouble, f.split(",")(1).toDouble, f.split(",")(2).toInt, f.split(",")(3).toInt, f.split(",")(4).toInt, f.split(",")(5).toInt, f.split(",")(6).toInt, f.split(",")(7).toInt, f.split(",")(8), f.split(",")(9))
      })


      hrRdd.take(10).foreach(println)
      println("####################################################################################")

      /*1*/
      hrRdd.map(f => {
        ((f._9,f._1),1)
      }).reduceByKey(_ + _).sortBy(_._1).foreach(println)
      println("####################################################################################")
      hrRdd.map(f => {
        ((f._9, f._1))
      }).reduceByKey(_ + _.round).sortBy(- _._2).foreach(println)
      println("####################################################################################")


      /*2*/
      hrRdd.filter(f => f._7 == 1).map(f => {
        (f._9, 1)
      }).reduceByKey(_ + _).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.filter(f => f._7 == 1).map(f => {
        (f._9, 1)
      }).reduceByKey(_ + _).sortBy(-_._2).foreach(println)
      println("####################################################################################")

      /*3*/
      hrRdd.map(f => {
        (f._9, f._4)
      }).reduceByKey(_ + _).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.map(f => {
        (f._9, f._4)
      }).reduceByKey(_ + _).sortBy(-_._2).foreach(println)
      println("####################################################################################")


      /*4*/
      hrRdd.map(f => {
        (f._9, f._3)
      }).reduceByKey(_ + _).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.map(f => {
        (f._9, f._3)
      }).reduceByKey(_ + _).sortBy(-_._2).foreach(println)
      println("####################################################################################")

      /*5*/
      hrRdd.map(f => {
        ((f._9, f._10), 1)
      }).reduceByKey(_ + _).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.map(f => {
        ((f._9, f._10), 1)
      }).reduceByKey(_ + _).sortBy(-_._2).foreach(println)
      println("####################################################################################")

      /*6*/
      hrRdd.filter(f => f._7 == 0 && f._8 == 1).map(f => {
        (f._9, 1)
      }).reduceByKey(_ + _).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.filter(f => f._7 == 0 && f._8 == 1).map(f => {
        (f._9, 1)
      }).reduceByKey(_ + _).sortBy(-_._2).foreach(println)
      println("####################################################################################")

      val maxExperience = hrRdd.map(f => {
        (f._5.toInt)
      }).max
      val totalProjects = hrRdd.map(f => {
        (f._3.toInt)
      }).sum
      val totalEmployees = hrRdd.map(f => {
        (f._8.toInt)
      }).count

      /*11*/
      hrRdd
      .filter(f => f._7 == 1).map(f => {
        (f._5, 1)
      }).reduceByKey(_ + _).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.filter(f => f._7 == 1).map(f => {
        (f._5, 1)
      }).reduceByKey(_ + _).sortBy(-_._2).foreach(println)
      println("####################################################################################")


      /*12*/
      hrRdd
        .filter(f => f._7 == 0).map(f => {
        (f._9, 1)
      }).reduceByKey(_ + _).filter(f => f._2 >= totalEmployees * 0.7).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.filter(f => f._7 == 0).map(f => {
        (f._9, 1)
      }).reduceByKey(_ + _).filter(f => f._2 >= totalEmployees * 0.7).sortBy(-_._2).foreach(println)
      println("####################################################################################")

      /*13*/
      hrRdd.filter(f => f._5 == maxExperience).map(f => {
        (f._9)
      }).distinct().sortBy(f => f, true).foreach(println)
      println("####################################################################################")

      /*14*/

      hrRdd.filter(f => f._5 == maxExperience).map(f => {
        ((f._9, f._10), 1)
      }).reduceByKey(_ + _).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.filter(f => f._5 == maxExperience).map(f => {
        ((f._9, f._10), 1)
      }).reduceByKey(_ + _).sortBy(-_._2).foreach(println)
      println("####################################################################################")

      /*15*/
      hrRdd.map(f => {
        (f._9, f._3)
      }).reduceByKey(_ + _).filter(f => f._2 >= totalProjects * 0.4).sortBy(_._2).foreach(println)
      println("####################################################################################")
      hrRdd.map(f => {
        (f._9, f._3)
      }).reduceByKey(_ + _).filter(f => f._2 >= totalProjects * 0.4).sortBy(-_._2).foreach(println)
      println("####################################################################################")

    }
    catch {
      case e: IOException => e.printStackTrace()
    }
  }


}
