package hr_data

import java.io.IOException

import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SparkSession

object hrdata {

  def main(args: Array[String]): Unit = {
    //val props = ConfigFactory.load()
    //val envProps = props.getConfig(args(0))

    val props = ConfigFactory.load()
    val envProps = props.getConfig(args(0))

    val spark = SparkSession
      .builder
      .master(envProps.getString("execution.mode"))
      .appName("HR Sample Data")
      .getOrCreate

    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.shuffle.partitions","2")

    /*val inputBaseDir = "/user/chaitanyapolipalli/bharath/HR_Analysis_Dataset.csv"
    val outputBaseDir = "/user/chaitanyapolipalli/bharath/output"*/
    try {
    val inputBaseDir = envProps.getString("input.base.dir")
    val outputBaseDir = envProps.getString("output.base.dir")

    val hr_data = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(inputBaseDir)
    hr_data.createOrReplaceTempView("hrData")

    /*1*/
    spark.sql("select sales, round(avg(satisfaction_level),2) as Avg from hrData group by sales order by Avg").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/1/")
    spark.sql("select sales, round(avg(satisfaction_level),2) as Avg from hrData group by sales order by Avg desc").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/1-1/")

    /*2*/
    spark.sql("select sales, count(left) as Total_Left from hrData where left = 0 group by sales order by Total_Left ").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/2/")
    spark.sql("select sales, count(left) as Total_Left from hrData where left = 0 group by sales order by Total_Left desc").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/2-2/")

    /*3*/
    spark.sql("select sales, round(avg(average_montly_hours),2) as Avg_Hours from hrData group by sales order by Avg_Hours").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/3/")
    spark.sql("select sales, round(avg(average_montly_hours),2) as Avg_Hours from hrData group by sales order by Avg_Hours desc").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/3-3/")

    /*4*/
    spark.sql("select sales, count(number_project) as Total_Projects from hrData group by sales order by Total_Projects ").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/4/")
    spark.sql("select sales, count(number_project) as Total_Projects from hrData group by sales order by Total_Projects desc").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/4-4/")

    /*5*/
    spark.sql("select salary, sales , count(salary) as Total from hrData group by salary, sales order by sales,salary").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/5/")
    spark.sql("select salary, sales , count(salary) as Total from hrData group by salary, sales order by sales desc,salary").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/5-5/")

    /*6*/
    spark.sql("select sales, count(left) as Total_Left from hrData where promotion_last_5years = 1 and left = 0 group by sales order by Total_Left ").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/6/")
    spark.sql("select sales, count(left) as Total_Left from hrData where promotion_last_5years = 1 and left = 0 group by sales order by Total_Left desc").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/6-6/")

    /*7*/
    spark.sql("select sales, round(avg(satisfaction_level),2) as Avg_Satisfaction, round(avg(average_montly_hours),2) as Avg_Working_Hours, count(left) as Total_Left from hrData where left = 0 group by sales order by Avg_Satisfaction,Avg_Working_Hours,Total_Left ").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/7/")
    spark.sql("select sales, round(avg(satisfaction_level),2) as Avg_Satisfaction, round(avg(average_montly_hours),2) as Avg_Working_Hours, count(left) as Total_Left from hrData where left = 0 group by sales order by Avg_Satisfaction desc,Avg_Working_Hours,Total_Left").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/7-7/")

    /*8*/
    spark.sql("select sales, salary, round(sum(satisfaction_level)/count(satisfaction_level),2) as Mean_Satisfaction, round(avg(average_montly_hours),2) as Avg_Working_Hours, count(left) as Total_Left from hrData where salary = 'low' and left = 0 group by sales, salary order by Mean_Satisfaction,Avg_Working_Hours,Total_Left ").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/8/")
    spark.sql("select sales, salary, round(sum(satisfaction_level)/count(satisfaction_level),2) as Mean_Satisfaction, round(avg(average_montly_hours),2) as Avg_Working_Hours, count(left) as Total_Left from hrData where salary = 'low' and left = 0 group by sales, salary order by Mean_Satisfaction desc,Avg_Working_Hours,Total_Left ").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/8-8/")

    /*9*/
    spark.sql("select sales,promotion_last_5years, round(sum(satisfaction_level)/count(satisfaction_level),2) as Mean_Satisfaction, round(avg(average_montly_hours),2) as Avg_Working_Hours, count(left) as Total_Left from hrData where salary = 'low' and promotion_last_5years = 1 and left = 0 group by sales, promotion_last_5years order by Mean_Satisfaction,Avg_Working_Hours,Total_Left").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/9/")
    spark.sql("select sales,promotion_last_5years, round(sum(satisfaction_level)/count(satisfaction_level),2) as Mean_Satisfaction, round(avg(average_montly_hours),2) as Avg_Working_Hours, count(left) as Total_Left from hrData where salary = 'low' and promotion_last_5years = 1 and left = 0 group by sales, promotion_last_5years order by Mean_Satisfaction desc,Avg_Working_Hours,Total_Left").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/9-9/")

    /*10*/
    val count_total = spark.sql(s"""SELECT CAST(count(left) AS Int) FROM hrData""").first.get(0)

    spark.sql(s"""select salary, round(avg(satisfaction_level),2) as Avg_Satisfaction_Level, round(avg(last_evaluation),2) as Avg_Last_Evaluation, count(left) as Total_Left, round(count(left)/$count_total * 100,2) as Percentage from hrData where left = 0 group by salary order by Percentage""").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/10/")
    spark.sql(s"""select salary, round(avg(satisfaction_level),2) as Avg_Satisfaction_Level, round(avg(last_evaluation),2) as Avg_Last_Evaluation, count(left) as Total_Left, round(count(left)/$count_total * 100,2) as Percentage from hrData where left = 0 group by salary order by Percentage desc""").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/10-10/")

    /*11*/
    spark.sql("select sales, time_spend_company , count(left) as Total_Left from hrData where left = 0 group by time_spend_company,sales order by time_spend_company,Total_left").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/11/")
    spark.sql("select sales, time_spend_company , count(left) as Total_Left from hrData where left = 0 group by time_spend_company,sales order by time_spend_company desc,Total_left").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/11-11/")

    /*12*/
    spark.sql(s"""select sales, round((count(left)/$count_total * 100),2)as Total_Employees, count(left)/$count_total * 100 > 70 as Total_Left_More_Than_70 from hrData group by sales order by Total_Employees""").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/12/")
    spark.sql(s"""select sales, round((count(left)/$count_total * 100),2)as Total_Employees, count(left)/$count_total * 100 > 70 as Total_Left_More_Than_70 from hrData group by sales order by Total_Employees desc""").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/12-12/")

    /*13*/
    val max_prjts = spark.sql(s"""SELECT CAST(MAX(number_project) AS Int) FROM hrData""").first.get(0)
    val hours = spark.sql(s"""select CAST(MAX(average_montly_hours) AS Double) from hrData""").first.get(0)
    spark.sql(s"""select distinct sales from hrData where number_project = $max_prjts and average_montly_hours = $hours group by sales""").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/13/")

    /*14*/
    spark.sql("select time_spend_company , count(salary) as Salary_Distribution, salary from hrData group by time_spend_company,salary order by time_spend_company,salary").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/14/")
    spark.sql("select time_spend_company , count(salary) as Salary_Distribution, salary from hrData group by time_spend_company,salary order by time_spend_company desc,salary").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/14-14/")

    /*15*/
    val count_prjts = spark.sql(s"""SELECT CAST(count(number_project) AS Int) FROM hrData""").first.get(0)

    spark.sql(s"""select sales, round((count(number_project)/$count_prjts * 100),2) as Total_Project_Per_Department_Share, count(number_project)/($count_prjts) * 100 > 40 as Total_Projects_Greater_Than_40 from hrData group by sales order by Total_Project_Per_Department_Share""").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/15/")
    spark.sql(s"""select sales, round((count(number_project)/$count_prjts * 100),2) as Total_Project_Per_Department_Share, count(number_project)/$count_prjts * 100 > 40 as Total_Projects_Greater_Than_40 from hrData group by sales order by Total_Project_Per_Department_Share desc""").coalesce(1).write.option("header", "true").csv(outputBaseDir+"/15-15/")

    }
    catch {
      case e: IOException => e.printStackTrace()
    }

  }

}
