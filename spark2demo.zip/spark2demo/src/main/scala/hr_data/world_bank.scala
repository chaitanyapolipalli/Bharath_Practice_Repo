package hr_data

import java.io.IOException

import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SparkSession

import scala.io.Source

object world_bank {

  def main(args: Array[String]): Unit = {
    //val props = ConfigFactory.load()
    //val envProps = props.getConfig(args(0))

    val props = ConfigFactory.load()
    val envProps = props.getConfig(args(0))

    val spark = SparkSession
      .builder
      .master(envProps.getString("execution.mode"))
      .appName("World Bank Data")
      .getOrCreate

    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.shuffle.partitions", "2")

    try {
      val inputBaseDir = envProps.getString("input.world_bank.base.dir")
      val outputBaseDir = envProps.getString("output.base.dir")


      val worldBankRaw = Source.fromFile(inputBaseDir).getLines().toList
//      val wbRdd = spark.sparkContext. parallelize(worldBankRaw)
      val wbRdd = spark.sparkContext.textFile(inputBaseDir)
      //val header = hrRddWithHeader.first()
      val wbRddNew = wbRdd.map(f => {
        (f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(0),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(1),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(2),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(3),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(4),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(5),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(6),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(7),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(8),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(9).replace(",","").replaceAll("\"", ""),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(10).replace(",","").replaceAll("\"", ""),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(11),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(12),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(13),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(14),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(15),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(16),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(17),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(18).replace(",","").replaceAll("\"", ""),
          f.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1)(19).replace(",","").replaceAll("\"", ""))

      })


      wbRddNew.take(20).foreach(println)

      val wbDF = spark.createDataFrame(wbRddNew).toDF("CountryName", "Date","TransitRailways", "TransitPassengerCars","BusinessMobilePhoneSubscribers", "BusinessInternetUsers","HealthMortalityUnder5", "HealthExpenditurePerCapita","HealthExpenditureTotalGDP","PopulationTotal","PopulationUrban","PopulationBirthRate","LifeExpectancyAtBirthFemale","LifeExpectancyAtBirthMale","LifeExpectancyAtBirthTotal","PopulationAges0_14","PopulationAges15_64","PopulationAges65+","FinanceGDP","FinanceGDPPerCapita")
      wbDF.createOrReplaceTempView("wbTable")

      spark.sql("select * from wbTable").show(10,false)
      /*1*/
      spark.sql("select CountryName,sum(PopulationUrban) as Total_Urban_Population from wbTable where PopulationUrban not like '' group by CountryName order by Total_Urban_Population desc limit 1").show(1000,false)

      /*2*/
      spark.sql("select CountryName,sum(PopulationTotal) as Total_Population from wbTable where PopulationTotal not like '' group by CountryName order by Total_Population desc").show(1000,false)

      /*3*/

//      val startDate = Calendar.DATE.toString
//      val formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy")
//      val oldDate = LocalDate.parse(startDate, formatter)
//      val currentDate = Calendar.DATE.toString
//      val newDate = LocalDate.parse(currentDate, formatter)
//      println(newDate.toEpochDay() - oldDate.toEpochDay())


      /*4*/
      spark.sql("select CountryName,sum(FinanceGDP) as Total_FinanceGDP,sum(FinanceGDPPerCapita) as Total_FinanceGDP_PerCapita from wbTable where (FinanceGDP not like '' or FinanceGDPPerCapita not like '') and (date like '%2009' or date like '%2010')  group by CountryName order by Total_FinanceGDP desc, Total_FinanceGDP_PerCapita desc").show(1000,false)

    }
    catch {
      case e: IOException => e.printStackTrace()
    }

  }
}
